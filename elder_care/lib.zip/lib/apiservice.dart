class RentApi {
  //'${_apiService.mainurl()}
  String mainurl() {
    //return 'http://gathikacolambage.site/eldercare/';
    return 'http://192.168.1.4/eldercare/';
    // return 'https://imagesuppliers.shopinmo.xyz/';
  }
}
